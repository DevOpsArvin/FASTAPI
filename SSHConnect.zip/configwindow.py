from tkinter import *
from SSHConnect import *
from netmiko import ConnectHandler
from tkinter import messagebox


def config(username, password, host):

    configWindow = Toplevel()
    configWindow.title("NetMoon")
    configWindow.iconbitmap("logo.ico")

    # set window specs
    configWindow.resizable(False,False)
    configWindow.geometry("400x400+450+150")

    # set font values
    fontFrame = ("Century Gothic", 11, "bold")
    chooseActionFont = ("Century Gothic", 13, "bold")
    copyRightFont=("Century Gothic", 7)

    # check checkbutton function for vlan
    def oncheckVlan():
        if chkVlan.get() == 1:
            vlanLabel["fg"] = "black"
            vlanEntry["state"] = "normal"
        else:
            vlanLabel["fg"] = "#C3C2BE"
            vlanEntry["state"] = "disabled"

    # check checkbutton function for voice
    def onCheckVoice():
        if chkVoice.get() == 1:
            voiceLabel["fg"] = "black"
            voiceEntry["state"] = "normal"
        else:
            voiceLabel["fg"] = "#C3C2BE"
            voiceEntry["state"] = "disabled"

    # def quit button
    def quit():
        configWindow.destroy()
        sys.exit()


    # Hostname/IP address validation
    def isValidIPadd(hostname):
        pattern = re.compile("^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$")
        isvalid = pattern.match(hostname)
        if isvalid:
            return True
        else:
            messagebox.showwarning("Error Message", "Invalid IP address")
            quit()

    def isValidVlan(vlanID):
        if vlanID.isdigit():
            return True
        else:
            messagebox.showwarning("Error Message", "Invalid input vlanID")
            quit()

    # function for apply button
    def applyConfig():
        message_info = []
        if isValidIPadd(hostName.get()) and not len(interface.get())==0:
            nocUser = User(username, password, hostName.get())
            net_connect = ConnectHandler(**nocUser.cisco())
            config_commands = configCommands(interface.get())

            if portChk.get() == 1:
                # function for port clearing
                clearPort(net_connect, interface.get())
                message_info.append("Port is cleared!\n")

            # for input validation for vlanID
            if chkVlan.get() == 1 and isValidVlan(vlanID.get()):
                # function for change vlan
                config_commands.insert(1, changeVlan(vlanID.get()))
                message_info.append("Changed the VLAN successfully\n")

            if chkVoice.get() == 1 and isValidVlan(voiceID.get()):
                # function for change voice vlan
                config_commands.insert(1, changeVoice(voiceID.get()))
                message_info.append("Changed the voice VLAN successfully\n")

            #execute config commands
            output = net_connect.send_config_set(config_commands)
            if "Invalid" in output:
                messagebox.showerror("Executed Config Commands", f"{output}\n Invalid Input!", parent=configWindow)
            else:
                output = f"{output}\n"
                for message in message_info:
                    output = output + message
                messagebox.showinfo("Executed Config Commands", output, parent=configWindow)
                # save configuration
                saveConfig(net_connect)


    # host frame widget
    hostIPFrame = LabelFrame(configWindow, padx=5, pady=5)
    hostIPFrame.pack(padx=10, pady=20)

    # hostname widget
    hostName = StringVar()
    hostName.set(f"{host}")
    hostIPLabel = Label(hostIPFrame, text="Host Name/IP address: ", font=fontFrame)
    hostIPEntry = Entry(hostIPFrame, textvariable=hostName, font=fontFrame, width=15)

    # interface widget
    interface = StringVar()
    interfaceLabel = Label(hostIPFrame, text="Interface/Port : ", font=fontFrame)
    interfaceEntry = Entry(hostIPFrame, textvariable=interface, font=fontFrame, width=15)

    # action frame widget
    actionFrame = LabelFrame(configWindow, text="Choose Action", font=chooseActionFont, padx=5, pady=5)
    actionFrame.pack(padx=10, pady=20)

    # interface/port clearing widget
    portChk =IntVar()
    portClrChkBtn = Checkbutton(actionFrame, text="Clear Port/Interface", font=fontFrame, variable=portChk)
    portClrChkBtn.select()

    # change access vlan widget
    vlanID = StringVar()
    chkVlan = IntVar()
    vlanLabel = Label(actionFrame, text="Enter Vlan-ID:", font=fontFrame, fg="#C3C2BE")
    vlanEntry = Entry(actionFrame, textvariable=vlanID, font=fontFrame, width=5, state="disabled")
    vlanCheckBtn = Checkbutton(actionFrame, text="Change Vlan            ", font=fontFrame, variable=chkVlan, command=oncheckVlan)

    # change voice vlan widget
    voiceID = StringVar()
    chkVoice = IntVar()
    voiceVlan = Checkbutton(actionFrame, text="Change Voice Vlan", font=fontFrame,variable=chkVoice, command=onCheckVoice)
    voiceLabel = Label(actionFrame, text="Enter Vlan-ID:", font=fontFrame, fg="#C3C2BE")
    voiceEntry = Entry(actionFrame, textvariable=voiceID, font=fontFrame, width=5, state="disabled")

    # Button Frame widget
    btnFrame = Frame(configWindow)
    exitBtn = Button(btnFrame, text="Exit", font=fontFrame, width=15, activebackground="#31302E", activeforeground="#F0F0F0", bg="#F0F0F0", fg="#31302E", command=quit)
    applyBtn = Button(btnFrame, text="Apply", font=fontFrame, width=15, activebackground="#31302E", activeforeground="#F0F0F0", bg="#F0F0F0", fg="#31302E", command=applyConfig)

    # copy right
    copyRightLabel = Label(configWindow, text="© Copyright 2021. All Rights Reserved. Developed by moonByteDev", font=copyRightFont, fg="#31302E")
    copyRightLabel.place(x=5,y=380)

    # host frame widget positions
    hostIPFrame.place(x=40, y=35, width=320)
    hostIPLabel.grid(row=0, column=0)
    hostIPEntry.grid(row=0, column=1,pady=3)
    interfaceLabel.grid(row=1, column=0,pady=3)
    interfaceEntry.grid(row=1, column=1)

    # action frame positions
    actionFrame.place(x=40, y=130, width=320, height= 180)
    portClrChkBtn.grid(row=0, column=0)
    vlanCheckBtn.grid(row=1, column=0)
    vlanLabel.grid(row=3, column=0)
    vlanEntry.grid(row=3,column=1)
    voiceVlan.grid(row=4, column=0)
    voiceLabel.grid(row=5, column=0)
    voiceEntry.grid(row=5,column=1)

    # Button frame positions
    btnFrame.place(x=40, y=330)
    exitBtn.grid(row=0, column=0,padx=10)
    applyBtn.grid(row=0, column=1)


