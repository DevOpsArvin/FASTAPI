# SSH session to Cisco switch
from netmiko import ConnectHandler

# Error/Exception Handling SSH Channel
from netmiko.ssh_exception import NetmikoTimeoutException
from netmiko.ssh_exception import SSHException
from netmiko.ssh_exception import AuthenticationException


class User:
    def __init__(self, username, password, hostname):
        self.username = username
        self.password = password
        self.hostname = hostname

# SSH session to Cisco switch
    def cisco(self):
        cisco = {
        'device_type': 'cisco_ios',
        'username': f'{self.username}',
        'password': f"{self.password}",
        'host': f'{self.hostname}'
        }
        return cisco
    # Error/Exception Handling SSH Channel

class NetConnection:
    def connect(cisco):
        try:
            ConnectHandler(**cisco)
            result = "Success"
            return result
        except (AuthenticationException):
            result = "Incorrect username or password"
        except (NetmikoTimeoutException):
            result = "Timeout to device"
        except (EOFError):
            result = "End of file while attempting device"
        except(SSHException):
            result = "SSH Issue. Are you sure SSH is enabled?"
        except Exception as unknown_error:
            result = f"Some other error: {unknown_error}"
            return result


# function for port clearing
def clearPort(net_connect, accessPort):
    # command for port clearing
    net_connect.send_command(f"clear port-security stick interface {accessPort}")


# function for change vlan
def changeVlan(vlanID):
    # commands for changing VLAN
    changeVlan = f'switchport access vlan {vlanID}'
    return changeVlan

# function for change voice vlan
def changeVoice(voiceVlanID):
    voiceVlan = f'switchport voice vlan {voiceVlanID}'
    return voiceVlan

# save configuration
def saveConfig(net_connect):
    net_connect.send_command("write memory")

# create list of configuration commands
def configCommands(interface):
    config_commands =[
        f'interface {interface}',
        'shutdown',
        'no shutdown'
    ]
    return  config_commands


