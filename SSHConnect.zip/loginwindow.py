from tkinter import *
from PIL import ImageTk, Image
from tkinter import messagebox
from SSHConnect import User, NetConnection
import configwindow


# creating login window
loginWindow = Tk()
loginWindow.title("NetMoon")
loginWindow.iconbitmap("logo.ico")

# validate login
def validateLogin():
	userCisco = username.get()
	userPass = password.get()
	userHost = hostname.get()
	cisco = User(userCisco, userPass, userHost)
	net_connect = cisco.cisco()
	result = NetConnection.connect(net_connect)
	if result == "Success" and net_connect:
		# run config window
		loginWindow.withdraw()
		configwindow.config(userCisco, userPass, userHost)
	elif result == "None":
		messagebox.showwarning("Error Message", "Invalid IP address")
	else:
		messagebox.showwarning("Error Message", f"{result}.")

def exit():
	loginWindow.destroy()

# set window size
loginWindow.resizable(False,False)
loginWindow.geometry("400x400+450+150")

# set window color
loginWindow['bg'] ='black'

# font styles
myFont = ("Century Gothic", 10, "bold")
fontColor = "#DAD9D7"
bgLabel = "black"
buttonFont = ("Berlin Sans FB Demi", 10, "bold")
windowLabelFont = ("Berlin Sans FB", 45, "bold")
fontEntry = ("Century Gothic", 9, "bold")

# moon image design
moon = ImageTk.PhotoImage(Image.open("images/login-moon-bg.png"))
moonLabel = Label(image=moon,width=300, height=200, bg="black")

# NetMoon logo design
windowLabelNet = Label(loginWindow, text="Net", bg="#F0F0F0", font=windowLabelFont)
windowLabelMoon = Label(loginWindow, text="Moon", bg="#31302E", fg="#F0F0F0", font=windowLabelFont)

# Host Name label and text entry box
hostnameLabel = Label(loginWindow, text="HOST NAME/ IP address", font=myFont, bg=bgLabel, fg=fontColor)
hostname = StringVar()
hostnameEntry = Entry(loginWindow, textvariable=hostname, font=fontEntry, width=30)

# username label and text entry box
usernameLabel = Label(loginWindow, text="USERNAME", font=myFont, bg=bgLabel, fg=fontColor)
username = StringVar()
usernameEntry = Entry(loginWindow, textvariable=username, font=fontEntry, width=30)

# password label and password entry box
passwordLabel = Label(loginWindow, text="PASSWORD", font=myFont, bg=bgLabel, fg=fontColor)
password = StringVar()
passwordEntry = Entry(loginWindow, textvariable=password, show='*',font=fontEntry, width=30)

# login button
loginButton = Button(loginWindow, text="SUBMIT", command=validateLogin, font=buttonFont, width=29, activebackground="#31302E", activeforeground="#F0F0F0", bg="#F0F0F0", fg="#31302E")

# copyright information
copyRightLabel = Label(loginWindow,text="© Copyright 2021. All Rights Reserved. Developed by moonByteDev", font=("Century Gothic", 7),bg ="black",fg="#C3C2BE")



# widget positions block
xOffset = 90
copyRightLabel.place(x=5, y=380)
moonLabel.place(x=120, y=-12)
windowLabelNet.place(x=20, y=45)
windowLabelMoon.place(x=130, y=45)
hostnameLabel.place(x=xOffset, y=175)
hostnameEntry.place(x=xOffset, y=200)
usernameLabel.place(x=xOffset, y=225)
usernameEntry.place(x=xOffset, y=250)
passwordLabel.place(x=xOffset, y=275)
passwordEntry.place(x=xOffset, y=300)
loginButton.place(x=xOffset+1, y=330)
hostnameLabel.place(x=xOffset, y=175)
hostnameEntry.place(x=xOffset, y=200)

loginWindow.mainloop()


